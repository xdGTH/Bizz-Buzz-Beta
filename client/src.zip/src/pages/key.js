let myKey = {
    publicTestKey: "test_public_key_77718f02b9664fd193ccbdcf1c96c464",
    secretKey: "test_secret_key_27409ff6b6f7436990d0f3fb83ae97f3",
  };
  
  export default myKey;